export async function up(queryInterface, Sequelize) {
  await queryInterface.createTable('oceny', {
    id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
    przejazd_id: {
      type: Sequelize.INTEGER,
      references: { model: 'przejazdy', key: 'id' },
      onDelete: 'CASCADE'
    },
    oceniajacy_id: {
      type: Sequelize.INTEGER,
      references: { model: 'uzytkownicy', key: 'id' },
      onDelete: 'CASCADE'
    },
    oceniany_id: {
      type: Sequelize.INTEGER,
      references: { model: 'uzytkownicy', key: 'id' },
      onDelete: 'CASCADE'
    },
    ocena: {
      type: Sequelize.TINYINT,
      validate: { min: 1, max: 5 }
    },
    komentarz: Sequelize.TEXT,
    data_utworzenia: { type: Sequelize.DATE, defaultValue: Sequelize.NOW }
  });
}

export async function down(queryInterface, Sequelize) {
  await queryInterface.dropTable('oceny');
}

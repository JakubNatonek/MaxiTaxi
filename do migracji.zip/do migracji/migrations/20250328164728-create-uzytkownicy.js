export async function up(queryInterface, Sequelize) {
  await queryInterface.createTable('uzytkownicy', {
    id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
    imie: Sequelize.STRING,
    email: { type: Sequelize.STRING, unique: true },
    telefon: Sequelize.STRING,
    haslo_hash: Sequelize.STRING,
    typ_uzytkownika: Sequelize.ENUM('pasażer', 'kierowca'),
    data_utworzenia: { type: Sequelize.DATE, defaultValue: Sequelize.NOW }
  });
}

export async function down(queryInterface, Sequelize) {
  await queryInterface.dropTable('uzytkownicy');
}
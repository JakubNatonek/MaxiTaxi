export async function up(queryInterface, Sequelize) {
  await queryInterface.createTable('lokalizacje', {
    id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
    uzytkownik_id: {
      type: Sequelize.INTEGER,
      references: { model: 'uzytkownicy', key: 'id' },
      onDelete: 'CASCADE'
    },
    szerokosc_geo: Sequelize.DECIMAL(10, 8),
    dlugosc_geo: Sequelize.DECIMAL(11, 8),
    zaktualizowano: {
      type: Sequelize.DATE,
      defaultValue: Sequelize.NOW
    }
  });
}
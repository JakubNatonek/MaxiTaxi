export async function up(queryInterface, Sequelize) {
  await queryInterface.createTable('przejazdy', {
    id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
    pasazer_id: {
      type: Sequelize.INTEGER,
      references: { model: 'uzytkownicy', key: 'id' },
      onDelete: 'SET NULL'
    },
    kierowca_id: {
      type: Sequelize.INTEGER,
      references: { model: 'uzytkownicy', key: 'id' },
      onDelete: 'SET NULL'
    },
    lokalizacja_start: Sequelize.STRING,
    lokalizacja_koniec: Sequelize.STRING,
    start_szerokosc: Sequelize.DECIMAL(10, 8),
    start_dlugosc: Sequelize.DECIMAL(11, 8),
    koniec_szerokosc: Sequelize.DECIMAL(10, 8),
    koniec_dlugosc: Sequelize.DECIMAL(11, 8),
    status: {
      type: Sequelize.ENUM(
        'zamówiony',
        'zaakceptowany',
        'w_trakcie',
        'zakończony',
        'anulowany'
      ),
      defaultValue: 'zamówiony'
    },
    data_zamowienia: Sequelize.DATE,
    data_rozpoczecia: Sequelize.DATE,
    data_zakonczenia: Sequelize.DATE,
    cena: Sequelize.DECIMAL(10, 2)
  });
}

export async function down(queryInterface, Sequelize) {
  await queryInterface.dropTable('przejazdy');
}
export async function up(queryInterface, Sequelize) {
  await queryInterface.createTable('kierowcy', {
    uzytkownik_id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      references: { model: 'uzytkownicy', key: 'id' },
      onDelete: 'CASCADE'
    },
    numer_prawa_jazdy: Sequelize.STRING,
    model_pojazdu: Sequelize.STRING,
    nr_rejestracyjny: Sequelize.STRING,
    kolor_pojazdu: Sequelize.STRING,
    ocena: { type: Sequelize.DECIMAL(3, 2), defaultValue: 5.0 }
  });
}

export async function down(queryInterface, Sequelize) {
  await queryInterface.dropTable('kierowcy');
}

export async function up(queryInterface, Sequelize) {
  await queryInterface.createTable('platnosci', {
    id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
    przejazd_id: {
      type: Sequelize.INTEGER,
      references: { model: 'przejazdy', key: 'id' },
      onDelete: 'CASCADE'
    },
    kwota: Sequelize.DECIMAL(10, 2),
    metoda_platnosci: Sequelize.ENUM('karta', 'gotówka', 'portfel'),
    status: {
      type: Sequelize.ENUM('oczekująca', 'zaplacona', 'nieudana'),
      defaultValue: 'oczekująca'
    },
    data_platnosci: Sequelize.DATE
  });
}

export async function down(queryInterface, Sequelize) {
  await queryInterface.dropTable('platnosci');
}

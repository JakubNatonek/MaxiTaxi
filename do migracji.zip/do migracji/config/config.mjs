export default {
    development: {
      username: 'root',
      password: '12345',
      database: 'MaxiTaxi_baza',
      host: 'localhost',
      dialect: 'mysql'
    }
  };
  
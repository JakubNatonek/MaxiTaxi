export interface Platnosc {
  id: number;
  przejazd_id: number;
  kwota: number;
  data: string; // lub Date
  id_uzytkownika: number;
}
